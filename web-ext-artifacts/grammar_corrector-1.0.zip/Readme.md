Demo project to use Mistral AI LLM to spellcheck a text

Build extension for Firefox
```
web-ext build
```

