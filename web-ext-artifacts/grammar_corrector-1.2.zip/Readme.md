Demo project to use Mistral AI LLM to spellcheck a text

Build extension for Firefox
```
web-ext build
```

Use firefox nightly or dev: `pacman -S firefox-developer-edition`

Go to `about:config`, change `xpinstall.signatures.required` to `false`.
Go to `about:addons`, and choose the Install Add-on from file option, choose the zip file created in the previous step.
Go to `about:config`, change `xpinstall.signatures.required` to `true`.
